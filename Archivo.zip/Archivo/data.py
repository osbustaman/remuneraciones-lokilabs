from data import *
from connection import *

colaborador = {
    "nombres": "paula andrea",
    "apellidos": "torres lobos",
    "rut": "13266183-9",
    "cargo": "desarrollador",
    "datos_laborales": [
        {
            "cargo": "programador bakend",
            "fecha_contrato": "05/10/2022",
            "tipo_contrato": "indefinido",
            "tipo_trabajador": "dependientes",

            "afp": {
              "codigo": 1,
              "nombre_afp": "Capital",
              "tasa_afp": 11.44,
              "sis": 1.85
            },
            "salud": {
              "tipo": "FONASA",
            }
        }
    ],
    "datos_renta": [
        {
            "gratificacion_legal": "SI",
            "tipo_gratificacion": "MENSUAL",
            "sueldo_base": 650000,
            "sueldo_liquido_deseado": 654800
        }
    ],
}


haberes = {
    "rut": "13266183-9",
    "haberes_imponibles": [],
    "haberes_no_imponibles": [
        {
            "movilizacion": 50000,
            "internet": 70000,
        }
    ],
}


# def insertar_data(data_colaborador):
#     db = connection()
#     collection = db['heberes']
#     # insert a single document
#     result = collection.insert_one(haberes)
#     print('Inserted document:', result.inserted_id)


# insertar_data(colaborador)
