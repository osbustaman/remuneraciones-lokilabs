import pywhatkit

contact = '+56961279565'

hour = 18
minute = 34

message = 'Esto es un test de prueba'

pywhatkit.sendwhatmsg_instantly(contact, message, hour, minute)