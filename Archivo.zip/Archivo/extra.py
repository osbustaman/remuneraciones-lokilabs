import pandas as pd
from bson.objectid import ObjectId

from connection import connection

def get_data():
    con = connection()
    collection = con['configurations']

    query_ = [
        {'$match': {'documentType' : 'groups', '_id' : ObjectId("60369c919de3320012d9ce20")}},
        {'$unwind': '$groups'},
        {'$unwind': '$groups.channels'},
    ]

    return list(collection.aggregate(query_))


def flatten_dict(d, parent_key='', sep='_'):

    _items = []
    for k, v in d.items():
        new_key = parent_key + sep + k if parent_key else k
        if isinstance(v, dict):
            _items.extend(flatten_dict(v, new_key, sep=sep).items())
        elif isinstance(v, list):
            for i, item in enumerate(v):
                if isinstance(item, dict):
                    _items.extend(flatten_dict(item, new_key + sep + str(i), sep=sep).items())
                else:
                    _items.append((new_key + sep + str(i), item))
        else:
            _items.append((new_key, v))

    return dict(_items)

flattened_data = [flatten_dict(d, sep='_') for d in get_data()]

# se crea el DataFrame conlos datos
df = pd.DataFrame(flattened_data)
df.to_excel('data_.xlsx', index=False)