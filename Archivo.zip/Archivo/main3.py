from babel.dates import format_date
from datetime import datetime, date, time


from functions import *
from data import *
from connection import *

def calcular_cotizacion_afp(salario_bruto, codigo_afp, tipo):
    tasa_cotizacion = 0
    for value in listado_afps:
        if value['codigo'] == codigo_afp:
            for v in value['tasa_trabajadores']:
                for key, val in v.items():
                    if key == tipo:
                        tasa_cotizacion = val['tasa_afp']

    cotizacion_afp = salario_bruto * (tasa_cotizacion / 100)
    return cotizacion_afp

def calcular_descuento_salud(salario_bruto, entidad_salud):
    # La tasa de descuento máxima para la salud en Chile es del 7%
    tasa_descuento_maxima = 0.07

    if entidad_salud == 'FONASA':
        # En el caso de FONASA, el descuento se aplica sobre el salario bruto
        descuento_salud = salario_bruto * tasa_descuento_maxima
    elif entidad_salud == 'ISAPRE':
        # En el caso de las ISAPRE, el descuento se aplica sobre el salario bruto en UF
        # Se puede obtener el valor de la UF utilizando una API o una fuente de datos confiable
        url = 'https://api.sbif.cl/api-sbifv3/recursos_api/uf?apikey=your_api_key&formato=json'
        response = requests.get(url)
        uf = response.json()['UFs'][0]['Valor']
        salario_bruto_uf = salario_bruto / uf
        descuento_salud = salario_bruto_uf * tasa_descuento_maxima
    else:
        raise ValueError('Entidad de salud no válida')

    return descuento_salud


def tope_gratificacion(sueldo_minimo, uf_tope, tipo_tope, sueldo_liquido, tiene_fratificacion = True):

    if tiene_fratificacion:

        monto_gratificacion = (sueldo_liquido * 12) * 0.25
        monto = sueldo_minimo * uf_tope

        if monto_gratificacion > monto:
            a_pago = monto
        else:
            a_pago = monto_gratificacion

        if tipo_tope == "MENSUAL":
            a_pago = round((a_pago/12), 0)
        return a_pago

    else:
        return False


def obtener_haberes(haberes_):

    total_haberes_imponibles = 0
    total_haberes_no_imponibles = 0
    for key, value in haberes_.items():
        if isinstance(value, list):
            if key == 'haberes_imponibles':
                for i, item in enumerate(value):
                    for k, v in item.items():
                        total_haberes_imponibles += v
        if key == 'haberes_no_imponibles':
            for i, item in enumerate(value):
                for k, v in item.items():
                    total_haberes_no_imponibles += v

    return total_haberes_imponibles, total_haberes_no_imponibles



def calcular_seguro_sesantia(base_imponible, tipo_contrato):
    # Calculamos el Seguro de Cesantía

    if tipo_contrato == 'indefinido':
        aporte_empleado = base_imponible * 0.006
        aporte_empleador = base_imponible * 0.024
    elif tipo_contrato in ['plazo_fijo', 'trabajador_casa_particular']:
        aporte_empleado = 0
        aporte_empleador = base_imponible * 0.03
    elif tipo_contrato == 'plazo_indefinido_mas_de_11_anios':
        aporte_empleado = 0
        aporte_empleador = base_imponible * 0.008

    return aporte_empleado, aporte_empleador

def datatime_to_timestamp(date_string):
    # codigo provisorio, despues la fecha vendra en timestamp
    date_object = datetime.strptime(date_string, '%Y-%m-%d').date()
    date_time_object = datetime.now()
    time_object = time(hour=date_time_object.hour, minute=date_time_object.minute, second=date_time_object.second)
    date_time_object = datetime.combine(date_object, time_object)

    timestamp = date_time_object.timestamp()
    return int(timestamp)


def calcular_impuesto_renta(salario_bruto):
    porcentaje_impuesto_renta = 0
    for value in parametros_impuesto_renta_mensual:
        if value['desde'] <= salario_bruto <= value['hasta']:
            porcentaje_impuesto_renta = salario_bruto * value['factor'] - value['cantidad_a_rebajar']

    return round(porcentaje_impuesto_renta, 0)


def calcular_liquidacion_sueldo():

    db = connection()
    collection = db['colaboradores']

    query = [
                {"$unwind": "$rut"},
                {
                    "$lookup": {
                        "from": "heberes",
                        "localField": "rut",
                        "foreignField": "rut",
                        "as": "documento_haberes"
                    }
                }
            ]

    cursor = collection.aggregate(query)

    date_object = datetime.now()
    year_actually = date_object.date().year
    month_name = format_date(date_object, format='MMMM', locale='es_ES')

    for document in cursor:
        # se crea un diccionario vacio
        dicc_renta = {}
        listado_haberes_imponibles = []
        listado_haberes_no_imponibles = []
        
        dicc_renta['nombre_colaborador'] = document['nombres'].title() + ' ' + document['apellidos'].title()
        dicc_renta['rut'] = document['rut'].upper()
        dicc_renta['mes'] = month_name.upper()
        dicc_renta['anio'] = year_actually
        dicc_renta['fecha_creacion_liquidacion'] = int(date_object.timestamp())
        dicc_renta['fecha_contrato'] = datatime_to_timestamp(document['datos_laborales'][0]['fecha_contrato'])
        dicc_renta['sueldo_base'] = document['datos_renta'][0]['sueldo_base']
        dicc_renta['sueldo_liquido_deseado'] = document['datos_renta'][0]['sueldo_liquido_deseado']
        dicc_renta['tipo_contrato'] = document['datos_laborales'][0]['tipo_contrato']

        tasa_afp = document['datos_laborales'][0]['afp']['tasa_afp']
        tipo_salud = document['datos_laborales'][0]['salud']['tipo']
        codigo_afp = document['datos_laborales'][0]['afp']['codigo']
        tipo_trabajador = document['datos_laborales'][0]['tipo_trabajador']


        sueldo_base = document['datos_renta'][0]['sueldo_base']
        gratificacion = tope_gratificacion(400000, 4.75, document['datos_renta'][0]['tipo_gratificacion'], document['datos_renta'][0]['sueldo_liquido_deseado'])
        haberes_ = document['documento_haberes'][0]
        
        
        haberes_imponibles, haberes_no_imponible = obtener_haberes(haberes_)

        total_haberes_imponibles = sueldo_base + gratificacion + haberes_imponibles

        listado_haberes_imponibles.append({"sueldo_base": sueldo_base})
        listado_haberes_imponibles.append({"gratificacion": gratificacion})

        for k, v in enumerate(haberes_['haberes_imponibles']):
            listado_haberes_imponibles.append(v)

        for k, v in enumerate(haberes_['haberes_no_imponibles']):
            listado_haberes_no_imponibles.append(v)

        haberes = [
            {
                "imponibles": {
                    "listado_haberes_imponibles": listado_haberes_imponibles,
                    "total_haberes_imponibles": total_haberes_imponibles
                }
            },{
                "no_imponibles": {
                    "listado_haberes_no_imponibles": listado_haberes_no_imponibles,
                    "total_haberes_no_imponible": haberes_no_imponible
                },
            }
        ]

        dicc_renta['haberes'] = haberes

        dicc_renta['tipo_contrato'] = document['datos_laborales'][0]['tipo_contrato']

        tasa_afp = document['datos_laborales'][0]['afp']['tasa_afp']
        tipo_salud = document['datos_laborales'][0]['salud']['tipo']
        codigo_afp = document['datos_laborales'][0]['afp']['codigo']
        tipo_trabajador = document['datos_laborales'][0]['tipo_trabajador']
        
        aporte_empleado, aporte_empleador = calcular_seguro_sesantia(total_haberes_imponibles, document['datos_laborales'][0]['tipo_contrato'])
        
        otros_descuentos = 0
        cotizacion_afp = calcular_cotizacion_afp(total_haberes_imponibles, codigo_afp, tipo_trabajador)
        cotizacion_salud = calcular_descuento_salud(total_haberes_imponibles, tipo_salud)

        total_descuentos = cotizacion_salud + cotizacion_afp + otros_descuentos
        
        

        
        sueldo_tributable = total_haberes_imponibles - total_descuentos - aporte_empleado
        dicc_renta['sueldo_tributable'] = sueldo_tributable

        impuesto_a_la_renta = calcular_impuesto_renta(sueldo_tributable)
        total_descuentos = total_descuentos + impuesto_a_la_renta + aporte_empleado

        descuentos = [
            {
                "cotizaciones": [
                    {
                        "apf": document['datos_laborales'][0]['afp']['nombre_afp'],
                        "tasa_afp": tasa_afp,
                        "tipo_trabajador": tipo_trabajador,
                        "cotizacion_afp": cotizacion_afp
                    },{
                        "salud": tipo_salud,
                        "cotizacion_salud": cotizacion_salud
                    },{
                        "descuento": "Seguro Cesantía (AFC)",
                        "aporte_empleado": aporte_empleado,
                        "aporte_empleador": aporte_empleador
                    },{
                        "Impuesto_a_la_renta": impuesto_a_la_renta
                    }
                ],
                "total_descuentos": total_descuentos,
            }
            
        ]
        
        dicc_renta['descuentos'] = descuentos
        dicc_renta['sueldo_liquido'] = (total_haberes_imponibles - total_descuentos) + haberes_no_imponible

        collection_remuneraciones = db['remuneraciones']
        #insert a single document
        result = collection_remuneraciones.insert_one(dicc_renta)
        print('Inserted document:', result.inserted_id)


calcular_liquidacion_sueldo()