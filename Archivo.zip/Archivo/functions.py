import requests
from utils import *
from data import *





def calculo_sueldo_tributable(sueldo_imponible, monto_afp, monto_salud, monto_seguro_sesantia):
    return sueldo_imponible - monto_afp - monto_salud - monto_seguro_sesantia








    

def calcular_horas_trabajadas(salario_bruto):
    valor_hora_extra = ((salario_bruto / 30) * 28) / 180
    return round(valor_hora_extra, 2)


def calcular_horas_extras(salario_bruto, cantidad_horas_extras):
    valor_hora_extra = (((salario_bruto / 30) * 28) / 180) * 0.5
    return round((valor_hora_extra * cantidad_horas_extras), 2)


def calcular_subtotal_imponible():
    pass

"""
Funciones de topes laborales
"""







def calculo_salario(colaborador, haberes):
    datos_liquidacion = colaborador

    datos_liquidacion['haberes'] = haberes
#     print(datos_liquidacion)

# calculo_salario(colaborador, haberes)


# def calcular_salario_neto(salario_bruto, codigo_afp, tipo_trabajador, tipo_entidad_salud):

#     cotizacion_afp = calcular_cotizacion_afp(salario_bruto, codigo_afp, tipo_trabajador)
#     cotizacion_salud = calcular_descuento_salud(salario_bruto, tipo_entidad_salud)
#     seguro_sesantia = calcular_seguro_sesantia(salario_bruto)
#     sueldo_imponible = calcular_sueldo_imponible(salario_bruto, cotizacion_afp, cotizacion_salud, seguro_sesantia)
#     sueldo_tributable = calculo_sueldo_tributable(sueldo_imponible, cotizacion_afp, cotizacion_salud, seguro_sesantia)
#     impuesto_renta = calcular_impuesto_renta(sueldo_tributable)

#     print("sueldo_tributable: ", sueldo_tributable)
#     print("impuesto_renta: ", impuesto_renta)
#     print("calcular_descuento_salud: ", calcular_descuento_salud(salario_bruto, tipo_entidad_salud))
#     print("calcular_cotizacion_afp: ", calcular_cotizacion_afp(salario_bruto, codigo_afp, tipo_trabajador))
#     print("seguro_sesantia: ", seguro_sesantia)
#     print("sueldo_imponible: ", sueldo_imponible)
 
 
    # Calcular las deducciones
    #deducciones = calcular_impuesto_renta(salario_bruto) + calcular_descuento_salud(salario_bruto, 'FONASA') + calcular_cotizacion_afp(salario_bruto, 1, 'dependientes')

    # Calcular el salario neto
    #salario_neto = salario_bruto - deducciones

    # return 0

# Ejemplo de cálculo del salario neto
# salario_bruto = 1900000

# salario_neto = calcular_salario_neto(salario_bruto, 1, 'dependientes', 'FONASA')
# print(f'El salario neto es: {salario_neto}')
