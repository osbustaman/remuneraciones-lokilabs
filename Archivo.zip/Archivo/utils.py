import requests
from datetime import date


APIKey = 'd8dd0e0dbbdb59bed5bf686c9c438e25c87c2cbc' 
dias_trabajados = 30
sueldo = 2070690


def get_utm(APIKey):
    utm = 'https://api.cmfchile.cl/api-sbifv3/recursos_api/utm?apikey='+ APIKey +'&formato=json'
    data_utm = requests.get(utm) 
    data_utm_json = data_utm.json()

    x_value = {}
    for key, value in data_utm_json.items():
        for dicc in value:
            x_value = dicc
    return dict(x_value)

def get_uf(APIKey):

  today = date.today()

  uf = f'https://api.cmfchile.cl/api-sbifv3/recursos_api/uf/{today.year}/{today.month}/dias/{today.day}?apikey={APIKey}&formato=json'

  data_uf = requests.get(uf)
  data_uf_json = data_uf.json()

  x_value = {}
  for key, value in data_uf_json.items():
    for dicc in value:
      x_value = dicc
  return dict(x_value)


def to_string_float_with_decimal(string):
  return float(string.replace(".", "").replace(",", "."))

def to_string_float(string):
  return float(string.replace(".", ""))

def calcular_monto_rango(valor, cantidad_utm, mas_uno = 0):
  return (valor * cantidad_utm) + mas_uno

# imm = 241000
# tope_anual = imm * 4.75
# tope_mensual = round((tope_anual / 12), 0)

# print('tope_anual: ', tope_anual)
# print('tope_mensual: ', tope_mensual)

"""
************************************************************************************
ESTA PARTE ES DE PARAMETROS INICIO
************************************************************************************
"""

parametros_impuesto_renta_mensual = [
    {
        "desde": 0,
        "hasta": calcular_monto_rango(to_string_float(get_utm(APIKey)['Valor']), 13.50),
        "factor": 0,
        "cantidad_a_rebajar": 0,
        "tipo_impuesto": 0
    },{
        "desde": calcular_monto_rango(to_string_float(get_utm(APIKey)['Valor']), 13.50, 1),
        "hasta": calcular_monto_rango(to_string_float(get_utm(APIKey)['Valor']), 30),
        "factor": 0.04,
        "cantidad_a_rebajar": (to_string_float(get_utm(APIKey)['Valor']) * 0.54),
        "tipo_impuesto": 2.20
    },{
        "desde": calcular_monto_rango(to_string_float(get_utm(APIKey)['Valor']), 30, 1),
        "hasta": calcular_monto_rango(to_string_float(get_utm(APIKey)['Valor']), 50),
        "factor": 0.08,
        "cantidad_a_rebajar": (to_string_float(get_utm(APIKey)['Valor']) * 1.74),
        "tipo_impuesto": 4.52
    },{
        "desde": calcular_monto_rango(to_string_float(get_utm(APIKey)['Valor']), 50, 1),
        "hasta": calcular_monto_rango(to_string_float(get_utm(APIKey)['Valor']), 70),
        "factor": 0.135,
        "cantidad_a_rebajar": (to_string_float(get_utm(APIKey)['Valor']) * 4.49),
        "tipo_impuesto": 7.09
    },{
        "desde": calcular_monto_rango(to_string_float(get_utm(APIKey)['Valor']), 70, 1),
        "hasta": calcular_monto_rango(to_string_float(get_utm(APIKey)['Valor']), 90),
        "factor": 0.23,
        "cantidad_a_rebajar": (to_string_float(get_utm(APIKey)['Valor']) * 11.14),
        "tipo_impuesto": 10.62
    },{
        "desde": calcular_monto_rango(to_string_float(get_utm(APIKey)['Valor']), 90, 1),
        "hasta": calcular_monto_rango(to_string_float(get_utm(APIKey)['Valor']), 120),
        "factor": 0.304,
        "cantidad_a_rebajar": (to_string_float(get_utm(APIKey)['Valor']) * 17.80),
        "tipo_impuesto": 15.57
    },{
        "desde": calcular_monto_rango(to_string_float(get_utm(APIKey)['Valor']), 120, 1),
        "hasta": calcular_monto_rango(to_string_float(get_utm(APIKey)['Valor']), 310),
        "factor": 0.35,
        "cantidad_a_rebajar": (to_string_float(get_utm(APIKey)['Valor']) * 23.32),
        "tipo_impuesto": 27.48
    },{
        "desde": calcular_monto_rango(to_string_float(get_utm(APIKey)['Valor']), 310, 1),
        "hasta": calcular_monto_rango(to_string_float(get_utm(APIKey)['Valor']), 310, 1),
        "factor": 0.4,
        "cantidad_a_rebajar": (to_string_float(get_utm(APIKey)['Valor']) * 38.82),
        "tipo_impuesto": 27.48
    },
]

parametros_impuesto_renta_mensual_2 = {
    "tipo_documento": "tramoImpuestoRentaSegundaCategoria",
    "parametros": [
        {
            "desde": 0,
            "hasta": calcular_monto_rango(to_string_float(get_utm(APIKey)['Valor']), 13.50),
            "factor": 0,
            "cantidad_a_rebajar": 0,
            "tipo_impuesto": 0
        },{
            "desde": calcular_monto_rango(to_string_float(get_utm(APIKey)['Valor']), 13.50, 1),
            "hasta": calcular_monto_rango(to_string_float(get_utm(APIKey)['Valor']), 30),
            "factor": 0.04,
            "cantidad_a_rebajar": (to_string_float(get_utm(APIKey)['Valor']) * 0.54),
            "tipo_impuesto": 2.20
        },{
            "desde": calcular_monto_rango(to_string_float(get_utm(APIKey)['Valor']), 30, 1),
            "hasta": calcular_monto_rango(to_string_float(get_utm(APIKey)['Valor']), 50),
            "factor": 0.08,
            "cantidad_a_rebajar": (to_string_float(get_utm(APIKey)['Valor']) * 1.74),
            "tipo_impuesto": 4.52
        },{
            "desde": calcular_monto_rango(to_string_float(get_utm(APIKey)['Valor']), 50, 1),
            "hasta": calcular_monto_rango(to_string_float(get_utm(APIKey)['Valor']), 70),
            "factor": 0.135,
            "cantidad_a_rebajar": (to_string_float(get_utm(APIKey)['Valor']) * 4.49),
            "tipo_impuesto": 7.09
        },{
            "desde": calcular_monto_rango(to_string_float(get_utm(APIKey)['Valor']), 70, 1),
            "hasta": calcular_monto_rango(to_string_float(get_utm(APIKey)['Valor']), 90),
            "factor": 0.23,
            "cantidad_a_rebajar": (to_string_float(get_utm(APIKey)['Valor']) * 11.14),
            "tipo_impuesto": 10.62
        },{
            "desde": calcular_monto_rango(to_string_float(get_utm(APIKey)['Valor']), 90, 1),
            "hasta": calcular_monto_rango(to_string_float(get_utm(APIKey)['Valor']), 120),
            "factor": 0.304,
            "cantidad_a_rebajar": (to_string_float(get_utm(APIKey)['Valor']) * 17.80),
            "tipo_impuesto": 15.57
        },{
            "desde": calcular_monto_rango(to_string_float(get_utm(APIKey)['Valor']), 120, 1),
            "hasta": calcular_monto_rango(to_string_float(get_utm(APIKey)['Valor']), 310),
            "factor": 0.35,
            "cantidad_a_rebajar": (to_string_float(get_utm(APIKey)['Valor']) * 23.32),
            "tipo_impuesto": 27.48
        },{
            "desde": calcular_monto_rango(to_string_float(get_utm(APIKey)['Valor']), 310, 1),
            "hasta": calcular_monto_rango(to_string_float(get_utm(APIKey)['Valor']), 310, 1),
            "factor": 0.4,
            "cantidad_a_rebajar": (to_string_float(get_utm(APIKey)['Valor']) * 38.82),
            "tipo_impuesto": 27.48
        },
    ]
}

listado_afps = [
    {
        "codigo": 1,
        "nombre_afp": "Capital",
        "tasa_trabajadores": [
            {
                "dependientes": {
                        "tasa_afp": 11.44,
                        "sis": 1.85
                },
            },{
                "independientes": {
                        "tasa_afp": 13.29,
                },
            }
        ]
    },{
        "codigo": 2,
        "nombre_afp": "Cuprum",
        "tasa_trabajadores": [
            {
                "dependientes": {
                        "tasa_afp": 11.44,
                        "sis": 1.85
                },
            },{
                "independientes": {
                        "tasa_afp": 13.29,
                },
            }
        ]
    },{
        "codigo": 3,
        "nombre_afp": "Habitat",
        "tasa_trabajadores": [
            {
                "dependientes": {
                        "tasa_afp": 11.27,
                        "sis": 1.85
                },
            },{
                "independientes": {
                        "tasa_afp": 13.12,
                },
            }
        ]
    },{
        "codigo": 4,
        "nombre_afp": "PlanVital",
        "tasa_trabajadores": [
            {
                "dependientes": {
                        "tasa_afp": 11.16,
                        "sis": 1.85
                },
            },{
                "independientes": {
                        "tasa_afp": 13.01,
                },
            }
        ]
    },{
        "codigo": 5,
        "nombre_afp": "Provida",
        "tasa_trabajadores": [
            {
                "dependientes": {
                        "tasa_afp": 11.45,
                        "sis": 1.85
                },
            },{
                "independientes": {
                        "tasa_afp": 13.30,
                },
            }
        ]
    },{
        "codigo": 6,
        "nombre_afp": "Modelo",
        "tasa_trabajadores": [
            {
                "dependientes": {
                        "tasa_afp": 10.58,
                        "sis": 1.85
                },
            },{
                "independientes": {
                        "tasa_afp": 12.43,
                },
            }
        ]
    },{
        "codigo": 7,
        "nombre_afp": "Uno",
        "tasa_trabajadores": [
            {
                "dependientes": {
                        "tasa_afp": 10.69,
                        "sis": 1.85
                },
            },{
                "independientes": {
                        "tasa_afp": 12.54,
                },
            }
        ]
    }
]

listado_afps_2 = {
    
    "tipo_documento": "listadoAfps",
    "listado_afps": [
        {
            "codigo": 1,
            "nombre_afp": "Capital",
            "tasa_trabajadores": [
                {
                    "dependientes": {
                            "tasa_afp": 11.44,
                            "sis": 1.85
                    },
                },{
                    "independientes": {
                            "tasa_afp": 13.29,
                    },
                }
            ]
        },{
            "codigo": 2,
            "nombre_afp": "Cuprum",
            "tasa_trabajadores": [
                {
                    "dependientes": {
                            "tasa_afp": 11.44,
                            "sis": 1.85
                    },
                },{
                    "independientes": {
                            "tasa_afp": 13.29,
                    },
                }
            ]
        },{
            "codigo": 3,
            "nombre_afp": "Habitat",
            "tasa_trabajadores": [
                {
                    "dependientes": {
                            "tasa_afp": 11.27,
                            "sis": 1.85
                    },
                },{
                    "independientes": {
                            "tasa_afp": 13.12,
                    },
                }
            ]
        },{
            "codigo": 4,
            "nombre_afp": "PlanVital",
            "tasa_trabajadores": [
                {
                    "dependientes": {
                            "tasa_afp": 11.16,
                            "sis": 1.85
                    },
                },{
                    "independientes": {
                            "tasa_afp": 13.01,
                    },
                }
            ]
        },{
            "codigo": 5,
            "nombre_afp": "Provida",
            "tasa_trabajadores": [
                {
                    "dependientes": {
                            "tasa_afp": 11.45,
                            "sis": 1.85
                    },
                },{
                    "independientes": {
                            "tasa_afp": 13.30,
                    },
                }
            ]
        },{
            "codigo": 6,
            "nombre_afp": "Modelo",
            "tasa_trabajadores": [
                {
                    "dependientes": {
                            "tasa_afp": 10.58,
                            "sis": 1.85
                    },
                },{
                    "independientes": {
                            "tasa_afp": 12.43,
                    },
                }
            ]
        },{
            "codigo": 7,
            "nombre_afp": "Uno",
            "tasa_trabajadores": [
                {
                    "dependientes": {
                            "tasa_afp": 10.69,
                            "sis": 1.85
                    },
                },{
                    "independientes": {
                            "tasa_afp": 12.54,
                    },
                }
            ]
        }
    ]
}

renta_topes_imponibles = [
  {
    "nombre": "afiliados_afp",
    "monto_uf": (to_string_float_with_decimal(get_uf(APIKey)['Valor']) * 81.6)
  },{
    "nombre": "afiliados_ips",
    "monto_uf": (to_string_float_with_decimal(get_uf(APIKey)['Valor']) * 60)
  },{
    "nombre": "seguro_sesantia",
    "monto_uf": (to_string_float_with_decimal(get_uf(APIKey)['Valor']) * 122.6)
  },
]

renta_topes_imponibles_2 = {
    "tipo_documento": "topesRentaImponibles",
    "listadoTopes": [
        {
            "nombre": "afiliados_afp",
            "monto_uf": (to_string_float_with_decimal(get_uf(APIKey)['Valor']) * 81.6)
        },{
            "nombre": "afiliados_ips",
            "monto_uf": (to_string_float_with_decimal(get_uf(APIKey)['Valor']) * 60)
        },{
            "nombre": "seguro_sesantia",
            "monto_uf": (to_string_float_with_decimal(get_uf(APIKey)['Valor']) * 122.6)
        },
    ]
}

parametros = {
    "tipo_documento": "parametrosRentas",
    "rentas_minimas" : [
        {
            "trabajadores_independientes": 400000,
            "menores_de_18": 298391,
            "mayores_de_65": 298391,
            "trabajadores_casas_pariticular": 400000,
            "fines_no_remuneracionales": 257836,
        }
    ]
}

"""
************************************************************************************
ESTA PARTE ES DE PARAMETROS FINAL
************************************************************************************
"""





