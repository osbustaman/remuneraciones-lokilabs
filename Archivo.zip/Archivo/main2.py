from functions import *
from data import *

def calcular_sueldo_liquido():

    sueldo_liquido_deseado = colaborador['datos_renta'][0]['sueldo_liquido_deseado']
    tipo_gratificacion = colaborador['datos_renta'][0]['tipo_gratificacion']

    tope_afiliado_afp = 0
    tope_afiliado_ips = 0
    tope_seguro_sesantia = 0
    haberes_imponibles_ = 0
    sueldo_minimo = parametros['rentas_minimas'][0]['trabajadores_independientes']

    haberes_imponibles, haberes_no_imponibles = obtener_haberes(haberes)
    subtotal = sueldo_liquido_deseado - haberes_no_imponibles
    
    for rti in renta_topes_imponibles: 
        if rti['nombre'] == 'afiliados_afp':
            tope_afiliado_afp = rti['monto_uf']

        if rti['nombre'] == 'afiliados_ips':
            tope_afiliado_ips = rti['monto_uf']

        if rti['nombre'] == 'seguro_sesantia':
            tope_seguro_sesantia = rti['monto_uf']

    tope_gratificacion_ = tope_gratificacion(sueldo_minimo, 4.75, tipo_gratificacion)
    tope_sueldo_gratificacion = tope_gratificacion_ / 0.25

    #cotizacion_afp = calcular_cotizacion_afp(salario_bruto, codigo_afp, tipo)

    cotizaciones_sobre_tope = ((colaborador['datos_laborales'][0]['afp']['tasa_afp'] / 100)+ 0.07 + 0.006) * tope_afiliado_afp
    incremento_cotizaciones = 100 - (((colaborador['datos_laborales'][0]['afp']['tasa_afp'] / 100)+ 0.07 + 0.006) * 100)

    if ((subtotal * 100) / incremento_cotizaciones) <= tope_afiliado_afp:
        sub_total_imponible = (subtotal * 100) / incremento_cotizaciones
    else:
        sub_total_imponible = (tope_afiliado_afp * 100) / incremento_cotizaciones

    estimacion_renta_tope = subtotal + cotizaciones_sobre_tope

    opcion_renta_sobre_tope = "SI" if estimacion_renta_tope > tope_afiliado_afp else "NO"

    gratificacion_calculada = (sub_total_imponible * 0.25) / 1.25

    if opcion_renta_sobre_tope == "SI":
        sueldo_base = subtotal + cotizaciones_sobre_tope - haberes_imponibles_ - tope_gratificacion_
    else:
        sueldo_base = sub_total_imponible - tope_gratificacion_ - haberes_imponibles_
    
    
    # print(' ********* CALCULOS COMPLEMENTARIOS ********* ')
    # print("TOPE GRATIFICACION: ", tope_gratificacion_)
    # print("TOPE SUELDO GRATIFICACION: ", tope_sueldo_gratificacion)
    # print("TIPO GRATIFICACION: ", tipo_gratificacion)
    # print("TOPE IMPONIBLE AFP: ", tope_afiliado_afp)
    # print("TOPE IMPONIBLE AFC: ", tope_seguro_sesantia)
    # print("HABERES NO IMPONIBLES : ", haberes_no_imponibles)
    # print("HABERES IMPONIBLES : ", haberes_imponibles)
    # print("SUELDO LIQUIDO DESEADO: ", sueldo_liquido_deseado)
    # print("SUBTOTAL : ", subtotal)
    # print("COTIZACIONES SOBRE TOPE: ", cotizaciones_sobre_tope)
    # print("INCREMENTO COTIZACIONES: ", incremento_cotizaciones)
    # print("SUB TOTAL IMPONIBLE: ", sub_total_imponible)
    # print("OPCION RENTA SOBRE TOPE: ", opcion_renta_sobre_tope)
    print("ESTIMACION RENTA SOBRE TOPE: ", estimacion_renta_tope)
    # print("GRATIFICACION CALCULADA: ", gratificacion_calculada)
    # print("SUELDO BASE: ", sueldo_base)
    # print(' ********* CALCULOS COMPLEMENTARIOS ********* ')

    print(' ********* CALCULOS LIQUIDACION ********* ')

    print("SUELDO LIQUIDO DESEADO: ", sueldo_liquido_deseado)


    print("SUELDO BASE: ", sueldo_base)
    print("OTROS BONOS IMPONIBLES: ", haberes_imponibles_)
    print("GRATIFICACION LEGAL: ", tope_gratificacion_)


    total_haberes_imponibles = sueldo_base + haberes_imponibles_ + tope_gratificacion_
    print("TOTAL DE HABERES IMPONIBLES ", total_haberes_imponibles)

    total_haberes_no_imponibles = haberes_no_imponibles
    # print("TOTAL DE HABERES NO IMPONIBLES ", total_haberes_no_imponibles)

    if total_haberes_imponibles <= tope_afiliado_afp:
        cotizacion_afp = calcular_cotizacion_afp(total_haberes_imponibles, colaborador['datos_laborales'][0]['afp']['codigo'], colaborador['datos_laborales'][0]['tipo_trabajador'])
        cotizacion_salud = calcular_descuento_salud(total_haberes_imponibles, colaborador['datos_laborales'][0]['salud']['tipo'])
        cotizacion_afc = calcular_seguro_sesantia(total_haberes_imponibles)
    else:
        cotizacion_afp = calcular_cotizacion_afp(tope_afiliado_afp, colaborador['datos_laborales'][0]['afp']['codigo'], colaborador['datos_laborales'][0]['tipo_trabajador'])
        cotizacion_salud = calcular_descuento_salud(tope_afiliado_afp, colaborador['datos_laborales'][0]['salud']['tipo'])
        cotizacion_afc = calcular_seguro_sesantia(tope_afiliado_afp)

    total_descuentos_legales = cotizacion_afp + cotizacion_salud + cotizacion_afc

    print("AFP ", cotizacion_afp)
    print("SALUD ", cotizacion_salud)
    print("AFC ", cotizacion_afc)

    # print("TOTAL DESCUENTOS LEGALES ", total_descuentos_legales)

    sueldo_liquido = (total_haberes_imponibles - total_descuentos_legales) + total_haberes_no_imponibles
    print("SUELDO LIQUIDO ", round(sueldo_liquido, 0))
    print(' ********* CALCULOS LIQUIDACION ********* ')

 
calcular_sueldo_liquido()# 1247705